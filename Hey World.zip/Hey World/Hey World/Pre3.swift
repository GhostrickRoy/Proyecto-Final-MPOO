//
//  Pre3.swift
//  Hey World
//
//  Created by Macbook on 5/20/19.
//  Copyright © 2019 IOSLAB. All rights reserved.
//

import UIKit

class Pre3: UIViewController {
    
    var viewController : Pre2!
    var suma3 : Int = 0

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func boton31(_ sender: Any) {
        performSegue(withIdentifier: "AlSig3", sender: nil)
        suma3 = viewController.suma2 + 10
        //print(suma3)
    }
    @IBAction func boton32(_ sender: Any) {
        performSegue(withIdentifier: "AlSig3", sender: nil)
        suma3 = viewController.suma2 + 20
    }
    @IBAction func boton33(_ sender: Any) {
        performSegue(withIdentifier: "AlSig3", sender: nil)
         suma3 = viewController.suma2 + 30
    }
    @IBAction func boton34(_ sender: Any) {
        performSegue(withIdentifier: "AlSig3", sender: nil)
         suma3 = viewController.suma2 + 40
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AlSig3" {
            let Cuarview = segue.destination as? Pre4
            Cuarview?.viewController = self
        }
    }
}
