//
//  Pantalla Espera.swift
//  Hey World
//
//  Created by Macbook on 5/27/19.
//  Copyright © 2019 IOSLAB. All rights reserved.
//

import UIKit

class Pantalla_Espera: UIViewController {
    
    @IBOutlet weak var reino: UILabel!
    @IBOutlet weak var accion: UILabel!
    @IBOutlet weak var DA: UILabel!
    @IBOutlet weak var poder: UILabel!
    @IBOutlet weak var DP: UILabel!
    @IBOutlet weak var objeto: UILabel!
    @IBOutlet weak var DO: UILabel!
    @IBOutlet weak var Rol: UILabel!
    @IBOutlet weak var DR: UILabel!
    
    var viewController : Pre10!
    
    var sumaTotal : Int = 0
    
    @IBOutlet weak var Iboton: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        reino.isHidden = true
        accion.isHidden = true
        DA.isHidden = true
        poder.isHidden = true
        DP.isHidden = true
        objeto.isHidden = true
        DO.isHidden = true
        Rol.isHidden = true
        DR.isHidden = true
    }
    @IBAction func resultado(_ sender: Any) {
        sumaTotal = viewController.suma10
        if sumaTotal == 100 {
            Iboton.image = UIImage(named:"Primavera")
            reino.text = "REINO PRIMAVERA"
            accion.text = "ACCIÓN:"
            DA.text = "CRECER"
            poder.text = "PODER:"
            DP.text = "DAR VIDA"
            objeto.text = "OBJETO:"
            DO.text = "FLOR"
            Rol.text = "ROL:"
            DR.text = "ANIMAL"
            
            reino.isHidden = false
            accion.isHidden = false
            DA.isHidden = false
            poder.isHidden = false
            DP.isHidden = false
            objeto.isHidden = false
            DO.isHidden = false
            Rol.isHidden = false
            DR.isHidden = false
        }
        if sumaTotal == 110 || sumaTotal == 120 {
            Iboton.image = UIImage(named:"Invierno")
            reino.text = "REINO INVIERNO"
            accion.text = "ACCIÓN:"
            DA.text = "CREER"
            poder.text = "PODER:"
            DP.text = "CONCEDER DESEOS"
            objeto.text = "OBJETO:"
            DO.text = "REGALO"
            Rol.text = "ROL:"
            DR.text = "GUÍA PRESENCIAL"
            
            reino.isHidden = false
            accion.isHidden = false
            DA.isHidden = false
            poder.isHidden = false
            DP.isHidden = false
            objeto.isHidden = false
            DO.isHidden = false
            Rol.isHidden = false
            DR.isHidden = false
        }
        if sumaTotal == 130 || sumaTotal == 140 || sumaTotal == 150 {
            Iboton.image = UIImage(named:"Juguete")
            reino.text = "REINO JUGUETE"
            accion.text = "ACCIÓN:"
            DA.text = "JUGAR"
            poder.text = "PODER:"
            DP.text = "MANEJAR LA ELECTRICIDAD"
            objeto.text = "OBJETO:"
            DO.text = "JUGUETE"
            Rol.text = "ROL:"
            DR.text = "NIÑO/A"
            
            reino.isHidden = false
            accion.isHidden = false
            DA.isHidden = false
            poder.isHidden = false
            DP.isHidden = false
            objeto.isHidden = false
            DO.isHidden = false
            Rol.isHidden = false
            DR.isHidden = false
        }
        if sumaTotal == 160 || sumaTotal == 170 {
            Iboton.image = UIImage(named:"Musical")
            reino.text = "REINO MUSICAL"
            accion.text = "ACCIÓN:"
            DA.text = "ESCUCHAR"
            poder.text = "PODER:"
            DP.text = "COMPONER MÚSICA"
            objeto.text = "OBJETO:"
            DO.text = "INSTRUMENTO MUSICAL"
            Rol.text = "ROL:"
            DR.text = "MAESTRO/A"
            
            reino.isHidden = false
            accion.isHidden = false
            DA.isHidden = false
            poder.isHidden = false
            DP.isHidden = false
            objeto.isHidden = false
            DO.isHidden = false
            Rol.isHidden = false
            DR.isHidden = false
        }
        if sumaTotal == 180 || sumaTotal == 190 || sumaTotal == 200 || sumaTotal == 210 {
            Iboton.image = UIImage(named:"Real")
            reino.text = "REINO REAL"
            accion.text = "ACCIÓN:"
            DA.text = "COMENZAR"
            poder.text = "PODER:"
            DP.text = "GOBERNAR EL MUNDO"
            objeto.text = "OBJETO:"
            DO.text = "CORONA"
            Rol.text = "ROL:"
            DR.text = "REY/REINA"
            
            reino.isHidden = false
            accion.isHidden = false
            DA.isHidden = false
            poder.isHidden = false
            DP.isHidden = false
            objeto.isHidden = false
            DO.isHidden = false
            Rol.isHidden = false
            DR.isHidden = false
        }
        if sumaTotal == 220 || sumaTotal == 230 || sumaTotal == 240 {
            Iboton.image = UIImage(named:"Heroes")
            reino.text = "REINO HÉROES"
            accion.text = "ACCIÓN:"
            DA.text = "PROTEGER"
            poder.text = "PODER:"
            DP.text = "INMUNIDAD"
            objeto.text = "OBJETO:"
            DO.text = "MONUMENTO"
            Rol.text = "ROL:"
            DR.text = "HÉROE"
            
            reino.isHidden = false
            accion.isHidden = false
            DA.isHidden = false
            poder.isHidden = false
            DP.isHidden = false
            objeto.isHidden = false
            DO.isHidden = false
            Rol.isHidden = false
            DR.isHidden = false
        }
        if sumaTotal == 250 || sumaTotal == 260 || sumaTotal == 270 {
            Iboton.image = UIImage(named:"Verano")
            reino.text = "REINO VERANO"
            accion.text = "ACCIÓN:"
            DA.text = "VIVIR"
            poder.text = "PODER:"
            DP.text = "CONTROLAR ELEMENTOS"
            objeto.text = "OBJETO:"
            DO.text = "SOL/LUNA"
            Rol.text = "ROL:"
            DR.text = "GUARDIÁN"
            
            reino.isHidden = false
            accion.isHidden = false
            DA.isHidden = false
            poder.isHidden = false
            DP.isHidden = false
            objeto.isHidden = false
            DO.isHidden = false
            Rol.isHidden = false
            DR.isHidden = false
        }
        if sumaTotal == 280 || sumaTotal == 290 {
            Iboton.image = UIImage(named:"Arte")
            reino.text = "REINO DEL ARTE"
            accion.text = "ACCIÓN:"
            DA.text = "CREAR"
            poder.text = "PODER:"
            DP.text = "DISEÑAR"
            objeto.text = "OBJETO:"
            DO.text = "COLOR"
            Rol.text = "ROL:"
            DR.text = "INVENTOR"
            
            reino.isHidden = false
            accion.isHidden = false
            DA.isHidden = false
            poder.isHidden = false
            DP.isHidden = false
            objeto.isHidden = false
            DO.isHidden = false
            Rol.isHidden = false
            DR.isHidden = false
        }
        if sumaTotal == 300 || sumaTotal == 310 || sumaTotal == 320 {
            Iboton.image = UIImage(named:"Corazon")
            reino.text = "REINO CORAZÓN"
            accion.text = "ACCIÓN:"
            DA.text = "AMAR"
            poder.text = "PODER:"
            DP.text = "ENAMORAR"
            objeto.text = "OBJETO:"
            DO.text = "CORAZÓN"
            Rol.text = "ROL:"
            DR.text = "CUPÍDO"
            
            reino.isHidden = false
            accion.isHidden = false
            DA.isHidden = false
            poder.isHidden = false
            DP.isHidden = false
            objeto.isHidden = false
            DO.isHidden = false
            Rol.isHidden = false
            DR.isHidden = false
        }
        if sumaTotal == 330 || sumaTotal == 340 {
            Iboton.image = UIImage(named:"Dulce")
            reino.text = "REINO DULCE"
            accion.text = "ACCIÓN:"
            DA.text = "DIVERTIR"
            poder.text = "PODER:"
            DP.text = "CONTROLAR EL TIEMPO"
            objeto.text = "OBJETO:"
            DO.text = "CARAMELO"
            Rol.text = "ROL:"
            DR.text = "HECHIZERO"
            
            reino.isHidden = false
            accion.isHidden = false
            DA.isHidden = false
            poder.isHidden = false
            DP.isHidden = false
            objeto.isHidden = false
            DO.isHidden = false
            Rol.isHidden = false
            DR.isHidden = false
        }
        if sumaTotal == 350 || sumaTotal == 360 || sumaTotal == 370 {
            Iboton.image = UIImage(named:"Otoño")
            reino.text = "REINO OTOÑO"
            accion.text = "ACCIÓN:"
            DA.text = "VIAJAR"
            poder.text = "PODER:"
            DP.text = "FANTASMAL"
            objeto.text = "OBJETO:"
            DO.text = "TORNADO"
            Rol.text = "ROL:"
            DR.text = "GUÍA ESPIRITUAL"
            
            reino.isHidden = false
            accion.isHidden = false
            DA.isHidden = false
            poder.isHidden = false
            DP.isHidden = false
            objeto.isHidden = false
            DO.isHidden = false
            Rol.isHidden = false
            DR.isHidden = false
        }
        if sumaTotal == 380 || sumaTotal == 390 || sumaTotal == 400 {
            Iboton.image = UIImage(named:"Calavera")
            reino.text = "REINO CALAVERA"
            accion.text = "ACCIÓN:"
            DA.text = "RECORDAR"
            poder.text = "PODER:"
            DP.text = "DESHACER"
            objeto.text = "OBJETO:"
            DO.text = "HUESO"
            Rol.text = "ROL:"
            DR.text = "VILLANO"
            
            reino.isHidden = false
            accion.isHidden = false
            DA.isHidden = false
            poder.isHidden = false
            DP.isHidden = false
            objeto.isHidden = false
            DO.isHidden = false
            Rol.isHidden = false
            DR.isHidden = false
        }
        print("La suma total es:",sumaTotal)
        }
}
