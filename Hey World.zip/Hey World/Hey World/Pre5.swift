//
//  Pre5.swift
//  Hey World
//
//  Created by Macbook on 5/24/19.
//  Copyright © 2019 IOSLAB. All rights reserved.
//

import UIKit

class Pre5: UIViewController {
    
    var viewController : Pre4!
    var suma5 : Int = 0

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func boton51(_ sender: Any) {
        performSegue(withIdentifier: "AlSig5", sender: nil)
        suma5 = viewController.suma4 + 10
        //print(suma5)
    }
    @IBAction func boton52(_ sender: Any) {
        performSegue(withIdentifier: "AlSig5", sender: nil)
        suma5 = viewController.suma4 + 20
    }
    @IBAction func boton53(_ sender: Any) {
        performSegue(withIdentifier: "AlSig5", sender: nil)
        suma5 = viewController.suma4 + 30
    }
    @IBAction func boton54(_ sender: Any) {
        performSegue(withIdentifier: "AlSig5", sender: nil)
        suma5 = viewController.suma4 + 40
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AlSig5" {
            let Sextview = segue.destination as? Pre6
            Sextview?.viewController = self
        }
    }
}
