//
//  Pre4.swift
//  Hey World
//
//  Created by Macbook on 5/24/19.
//  Copyright © 2019 IOSLAB. All rights reserved.
//

import UIKit

class Pre4: UIViewController {
    
    var viewController : Pre3!
    var suma4 : Int = 0

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func boton41(_ sender: Any) {
        performSegue(withIdentifier: "AlSig4", sender: nil)
        suma4 = viewController.suma3 + 10
        //print(suma4)
    }
    @IBAction func boton42(_ sender: Any) {
        performSegue(withIdentifier: "AlSig4", sender: nil)
        suma4 = viewController.suma3 + 20
    }
    @IBAction func boton43(_ sender: Any) {
        performSegue(withIdentifier: "AlSig4", sender: nil)
        suma4 = viewController.suma3 + 30
    }
    @IBAction func boton44(_ sender: Any) {
        performSegue(withIdentifier: "AlSig4", sender: nil)
        suma4 = viewController.suma3 + 40
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AlSig4" {
            let Quinview = segue.destination as? Pre5
            Quinview?.viewController = self
        }
    }
}
