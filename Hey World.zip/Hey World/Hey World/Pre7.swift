//
//  Pre7.swift
//  Hey World
//
//  Created by Macbook on 5/24/19.
//  Copyright © 2019 IOSLAB. All rights reserved.
//

import UIKit

class Pre7: UIViewController {
    
    var viewController : Pre6!
    var suma7 : Int = 0

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func boton71(_ sender: Any) {
        performSegue(withIdentifier: "AlSig7", sender: nil)
        suma7 = viewController.suma6 + 10
        //print(suma7)
    }
    @IBAction func boton72(_ sender: Any) {
        performSegue(withIdentifier: "AlSig7", sender: nil)
        suma7 = viewController.suma6 + 20
    }
    @IBAction func boton73(_ sender: Any) {
        performSegue(withIdentifier: "AlSig7", sender: nil)
        suma7 = viewController.suma6 + 30
    }
    @IBAction func boton74(_ sender: Any) {
        performSegue(withIdentifier: "AlSig7", sender: nil)
        suma7 = viewController.suma6 + 40
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AlSig7" {
            let Octaview = segue.destination as? Pre8
            Octaview?.viewController = self
        }
    }
}
