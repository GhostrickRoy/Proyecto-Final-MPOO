//
//  Pre8.swift
//  Hey World
//
//  Created by Macbook on 5/24/19.
//  Copyright © 2019 IOSLAB. All rights reserved.
//
/*hola asi se pone el comentario*/
import UIKit

class Pre8: UIViewController {
    
    var viewController : Pre7!
    var suma8 : Int = 0

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func boton81(_ sender: Any) {
        performSegue(withIdentifier: "AlSig8", sender: nil)
        suma8 = viewController.suma7 + 10
        //print(suma8)
    }
    @IBAction func boton82(_ sender: Any) {
        performSegue(withIdentifier: "AlSig8", sender: nil)
        suma8 = viewController.suma7 + 20
    }
    @IBAction func boton83(_ sender: Any) {
        performSegue(withIdentifier: "AlSig8", sender: nil)
        suma8 = viewController.suma7 + 30
    }
    @IBAction func boton84(_ sender: Any) {
        performSegue(withIdentifier: "AlSig8", sender: nil)
        suma8 = viewController.suma7 + 40
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AlSig8" {
            let Noveview = segue.destination as? Pre9
            Noveview?.viewController = self
        }
    }
}
