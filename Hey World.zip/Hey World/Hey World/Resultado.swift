//
//  Resultado.swift
//  Hey World
//
//  Created by Macbook on 5/27/19.
//  Copyright © 2019 IOSLAB. All rights reserved.
//

import UIKit

class Resultado: UIViewController {
    
    @IBOutlet weak var ImagenBoton: UIImageView!
    var viewController : Pantalla_Espera!
    var sumaResultado: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
   // sumaResultado = viewController.sumaTotal
}

