//
//  Pre6.swift
//  Hey World
//
//  Created by Macbook on 5/24/19.
//  Copyright © 2019 IOSLAB. All rights reserved.
//

import UIKit

class Pre6: UIViewController {
    
    var viewController : Pre5!
    var suma6 : Int = 0

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func boton61(_ sender: Any) {performSegue(withIdentifier: "AlSig6", sender: nil)
        suma6 = viewController.suma5 + 10
        //print(suma6)
    }
    @IBAction func boton62(_ sender: Any) {
        performSegue(withIdentifier: "AlSig6", sender: nil)
        suma6 = viewController.suma5 + 20
    }
    @IBAction func boton63(_ sender: Any) {
        performSegue(withIdentifier: "AlSig6", sender: nil)
        suma6 = viewController.suma5 + 30
    }
    @IBAction func boton64(_ sender: Any) {
        performSegue(withIdentifier: "AlSig6", sender: nil)
        suma6 = viewController.suma5 + 40
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AlSig6" {
            let Septview = segue.destination as? Pre7
            Septview?.viewController = self
        }
    }
}
