//
//  Pre2.swift
//  Hey World
//
//  Created by Macbook on 5/20/19.
//  Copyright © 2019 IOSLAB. All rights reserved.
//

import UIKit

class Pre2: UIViewController {
    
    var viewController : Pre1!
    var suma2 : Int = 0
    // var firstView : ViewController!

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func boton21(_ sender: Any) {
         performSegue(withIdentifier: "AlSig2", sender: nil)
        suma2 = viewController.suma1 + 10
        //print(suma2)
    }
    @IBAction func boton22(_ sender: Any) {
        performSegue(withIdentifier: "AlSig2", sender: nil)
        suma2 = viewController.suma1 + 20
    }
    @IBAction func boton23(_ sender: Any) {
        performSegue(withIdentifier: "AlSig2", sender: nil)
        suma2 = viewController.suma1 + 30
    }
    @IBAction func boton24(_ sender: Any) {performSegue(withIdentifier: "AlSig2", sender: nil)
        suma2 = viewController.suma1 + 40
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AlSig2" {
            let Tercview = segue.destination as? Pre3
            Tercview?.viewController = self
      }
   }
}
