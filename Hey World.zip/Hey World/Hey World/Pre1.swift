//
//  Pre1.swift
//  Hey World
//
//  Created by Macbook on 5/20/19.
//  Copyright © 2019 IOSLAB. All rights reserved.
//

import UIKit

class Pre1: UIViewController {
    
    var suma1 : Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func boton11(_ sender: Any) {
         performSegue(withIdentifier: "AlSig1", sender: nil)
        suma1 = 10
    }
    @IBAction func boton12(_ sender: Any) {
         performSegue(withIdentifier: "AlSig1", sender: nil)
        suma1 = 20
    }
    @IBAction func boton13(_ sender: Any) {
         performSegue(withIdentifier: "AlSig1", sender: nil)
        suma1 = 30
    }
    @IBAction func boton14(_ sender: Any) {
         performSegue(withIdentifier: "AlSig1", sender: nil)
        suma1 = 40
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AlSig1" {
            let Seguview = segue.destination as? Pre2
            Seguview?.viewController = self
        }
    }
}
