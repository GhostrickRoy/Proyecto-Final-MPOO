//
//  Pre9.swift
//  Hey World
//
//  Created by Macbook on 5/24/19.
//  Copyright © 2019 IOSLAB. All rights reserved.
//

import UIKit

class Pre9: UIViewController {
    
    var viewController : Pre8!
    var suma9 : Int = 0

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func boton91(_ sender: Any) {
        performSegue(withIdentifier: "AlSig9", sender: nil)
        suma9 = viewController.suma8 + 10
        //print(suma9)
    }
    @IBAction func boton92(_ sender: Any) {
        performSegue(withIdentifier: "AlSig9", sender: nil)
        suma9 = viewController.suma8 + 20
    }
    @IBAction func boton93(_ sender: Any) {
        performSegue(withIdentifier: "AlSig9", sender: nil)
        suma9 = viewController.suma8 + 30
    }
    @IBAction func boton94(_ sender: Any) {
        performSegue(withIdentifier: "AlSig9", sender: nil)
        suma9 = viewController.suma8 + 40
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AlSig9" {
            let Deciview = segue.destination as? Pre10
            Deciview?.viewController = self
        }
    }
}
