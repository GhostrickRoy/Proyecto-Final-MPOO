//
//  Pre10.swift
//  Hey World
//
//  Created by Macbook on 5/24/19.
//  Copyright © 2019 IOSLAB. All rights reserved.
//

import UIKit

class Pre10: UIViewController {
    
    var viewController : Pre9!
    var suma10 : Int = 0

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func boton101(_ sender: Any) {
        performSegue(withIdentifier: "AlSig10", sender: nil)
        suma10 = viewController.suma9 + 10
        //print(suma10)
    }
    @IBAction func boton102(_ sender: Any) {
        performSegue(withIdentifier: "AlSig10", sender: nil)
        suma10 = viewController.suma9 + 20
    }
    @IBAction func boton103(_ sender: Any) {
        performSegue(withIdentifier: "AlSig10", sender: nil)
        suma10 = viewController.suma9 + 30
    }
    @IBAction func boton104(_ sender: Any) {
        performSegue(withIdentifier: "AlSig10", sender: nil)
        suma10 = viewController.suma9 + 40
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AlSig10" {
            let PEview = segue.destination as? Pantalla_Espera
            PEview?.viewController = self
        }
    }
}
